import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-developer',
  templateUrl: './edit-developer.page.html',
  styleUrls: ['./edit-developer.page.scss'],
})
export class EditDeveloperPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
